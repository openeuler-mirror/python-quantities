"""
"""
from __future__ import absolute_import

from ..unitquantity import CompoundUnit

pc_per_cc = CompoundUnit("pc/cm**3")
